# Overview

TX Battle Royale is a React-based multiplayer mini-app built for the Farcaster platform. It's a real-time gaming application where players make predictions about transaction counts and compete against each other in a battle royale format. The app features live chat, leaderboards, player management, and wallet connectivity integration with Farcaster's miniapp ecosystem.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite as the build tool
- **Component Structure**: Modular component-based architecture with separation of concerns
  - `App.tsx` serves as the main entry point with splash screen logic
  - `GameUI.tsx` acts as the main game container orchestrating all game components
  - Individual components for specific features (Chat, Predictions, Leaderboard, etc.)
- **State Management**: Local React state with useState hooks, no global state management library
- **Styling**: Custom CSS with CSS variables for theming and responsive grid layout

## Real-time Communication
- **WebSocket Integration**: Socket.IO client for real-time bidirectional communication
- **Connection Management**: Centralized socket connection handling in `utils/socket.ts`
- **Event-driven Architecture**: Components subscribe to socket events for live updates (chat messages, player lists, leaderboard updates)

## Farcaster Integration
- **Miniapp SDK**: Integration with `@farcaster/miniapp-sdk` for Farcaster platform features
- **Wallet Connectivity**: Built-in wallet connection functionality through Farcaster SDK
- **Manifest Configuration**: Properly configured `farcaster.json` in `.well-known` directory for miniapp registration
- **Meta Tags**: Farcaster-specific meta tags for miniapp discovery and launching

## Deployment Strategy
- **Frontend Deployment**: Configured for static hosting (Netlify recommended)
- **Backend Separation**: Frontend communicates with separate backend service via configurable URLs
- **Environment Configuration**: Flexible backend URL configuration through environment variables and config file

# External Dependencies

## Core Dependencies
- **React Ecosystem**: React 18.2.0 and React DOM for UI rendering
- **Farcaster SDK**: `@farcaster/miniapp-sdk` for platform integration and wallet connectivity
- **Socket.IO Client**: Version 4.7.2 for real-time WebSocket communication with backend

## Development Tools
- **Vite**: Modern build tool and development server with React plugin
- **TypeScript**: Type safety and better development experience
- **Type Definitions**: React and React DOM type definitions for TypeScript support

## Backend Services
- **Game Server**: External backend service (Replit-hosted) handling game logic, player management, and WebSocket connections
- **Real-time Features**: Chat messaging, leaderboard updates, player synchronization through WebSocket events

## Platform Integration
- **Farcaster Platform**: Deep integration with Farcaster's miniapp ecosystem for user authentication and wallet management
- **Web Share API**: Native browser sharing functionality for game invitations