import React, { useEffect, useState } from 'react';
import Splash from './components/Splash';
import GameUI from './components/GameUI';
import { connectSocket } from './utils/socket';
import { farcasterService } from './services/farcasterService';

const App: React.FC = () => {
  const [ready, setReady] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('Initializing app...');
    
    // Initialize SDK if in Farcaster environment
    const initSDK = async () => {
      if (farcasterService.isFarcasterEnvironment()) {
        console.log('Farcaster environment detected, calling SDK ready...');
        const sdkReady = await farcasterService.callSDKReady();
        console.log('SDK ready result:', sdkReady);
      } else {
        console.log('Running in development mode (not in Farcaster environment)');
      }
    };
    
    initSDK();

    // Connect to socket
    const socket = connectSocket();
    
    const handleConnect = async () => {
      console.log('Socket connected, attempting SDK ready again...');
      if (farcasterService.isFarcasterEnvironment()) {
        await farcasterService.callSDKReady();
      }
      setReady(true);
      setLoading(false);
    };

    socket.on('connect', handleConnect);

    // In development mode, set ready after a short timeout
    const timeout = setTimeout(() => {
      console.log('Timeout reached, setting app as ready');
      setReady(true);
      setLoading(false);
    }, 2000);

    // Proper cleanup function
    return () => {
      clearTimeout(timeout);
      socket.off('connect', handleConnect);
    };
  }, []);

  if (loading) {
    return <Splash />;
  }

  return ready ? <GameUI /> : <Splash />;
};

export default App;
