import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { farcasterService, FarcasterUser } from '../services/farcasterService';

interface UserContextType {
  user: FarcasterUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (user: FarcasterUser) => void;
  logout: () => void;
  refreshUser: (fid?: number) => Promise<void>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [user, setUser] = useState<FarcasterUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const login = (userData: FarcasterUser) => {
    setUser(userData);
    setIsAuthenticated(true);
    console.log('User logged in:', userData.username);
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    console.log('User logged out');
  };

  const refreshUser = async (fid?: number) => {
    if (!fid && !user?.fid) return;
    
    setIsLoading(true);
    try {
      const userData = await farcasterService.getUserByFid(fid || user!.fid);
      setUser(userData);
      setIsAuthenticated(true);
    } catch (error) {
      console.error('Failed to refresh user data:', error);
      logout();
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const initializeUser = async () => {
      setIsLoading(true);
      try {
        // Check if user is available from Farcaster context
        const currentUser = await farcasterService.getCurrentUser();
        if (currentUser?.fid) {
          const userData = await farcasterService.getUserByFid(currentUser.fid);
          login(userData);
        }
      } catch (error) {
        console.log('No user context available on initialization');
      } finally {
        setIsLoading(false);
      }
    };

    initializeUser();
  }, []);

  const value: UserContextType = {
    user,
    isLoading,
    isAuthenticated,
    login,
    logout,
    refreshUser,
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};

export default UserContext;