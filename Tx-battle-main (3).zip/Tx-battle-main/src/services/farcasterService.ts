export interface FarcasterUser {
  fid: number;
  username: string;
  displayName: string;
  pfpUrl: string;
  custody_address: string;
  verification_addresses: string[];
  follower_count: number;
  following_count: number;
  bio?: string;
}

export interface NeynarAPIResponse<T> {
  result: T;
}

class FarcasterService {
  private apiKey: string;
  private baseUrl = 'https://api.neynar.com/v2/farcaster';

  constructor() {
    // For security, API calls should be made through a backend proxy
    // In development mode, this service focuses on SDK interactions
    this.apiKey = '';
    console.log('FarcasterService initialized - API calls require backend proxy for security');
  }

  private async makeRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-API-KEY': this.apiKey,
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Neynar API error: ${response.status} - ${error}`);
    }

    return response.json();
  }

  async getUserByFid(fid: number): Promise<FarcasterUser> {
    const response = await this.makeRequest<NeynarAPIResponse<{ user: FarcasterUser }>>(`/user/by_fid?fid=${fid}`);
    return response.result.user;
  }

  async getUserByUsername(username: string): Promise<FarcasterUser> {
    const response = await this.makeRequest<NeynarAPIResponse<{ user: FarcasterUser }>>(`/user/by_username?username=${username}`);
    return response.result.user;
  }

  async getUsersByAddresses(addresses: string[]): Promise<FarcasterUser[]> {
    const addressParams = addresses.map(addr => `addresses=${addr}`).join('&');
    const response = await this.makeRequest<NeynarAPIResponse<FarcasterUser[]>>(`/user/by_verification?${addressParams}`);
    return response.result;
  }

  // Utility method to check if we're in Farcaster environment
  isFarcasterEnvironment(): boolean {
    return typeof window !== 'undefined' && (
      !!(window as any).farcasterSdk || 
      !!(window as any).FarcasterMiniapp || 
      !!(window as any).miniapp
    );
  }

  // Get the SDK instance if available
  getSDK(): any {
    if (typeof window === 'undefined') return null;
    return (window as any).farcasterSdk || (window as any).FarcasterMiniapp || (window as any).miniapp;
  }

  // Call SDK ready with proper error handling
  async callSDKReady(): Promise<boolean> {
    try {
      const sdk = this.getSDK();
      if (sdk?.actions?.ready) {
        await sdk.actions.ready();
        return true;
      } else if (sdk?.ready) {
        await sdk.ready();
        return true;
      }
      return false;
    } catch (error) {
      console.warn('SDK ready failed:', error);
      return false;
    }
  }

  // Get current user context from SDK
  async getCurrentUser(): Promise<{ fid?: number } | null> {
    try {
      const sdk = this.getSDK();
      if (sdk?.context) {
        return sdk.context.user || null;
      }
      return null;
    } catch (error) {
      console.warn('Failed to get current user context:', error);
      return null;
    }
  }

  // Connect wallet through SDK
  async connectWallet(): Promise<{ address?: string } | null> {
    try {
      const sdk = this.getSDK();
      if (sdk?.actions?.connectWallet) {
        return await sdk.actions.connectWallet();
      }
      return null;
    } catch (error) {
      console.warn('Wallet connection failed:', error);
      return null;
    }
  }
}

export const farcasterService = new FarcasterService();
export default farcasterService;