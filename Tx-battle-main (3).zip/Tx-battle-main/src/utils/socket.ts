import { io, Socket } from "socket.io-client";
import { BACKEND_URL } from "../config";

const SOCKET_BACKEND_URL = import.meta.env.VITE_BACKEND_URL || BACKEND_URL;

let socket: Socket | null = null;

// 🔌 Fungsi untuk menghubungkan socket
export function connectSocket(): Socket {
  if (!socket) {
    socket = io(SOCKET_BACKEND_URL, {
      transports: ["websocket"],
    });
    console.log("✅ Socket connected to", SOCKET_BACKEND_URL);
  }
  return socket;
}

// 🔌 Getter supaya komponen lain bisa ambil instance yg sama
export function getSocket(): Socket {
  if (!socket) {
    return connectSocket();
  }
  return socket;
}

// default export → supaya kompatibel juga
export default {
  connectSocket,
  getSocket,
};
