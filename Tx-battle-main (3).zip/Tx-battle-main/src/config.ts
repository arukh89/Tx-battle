export const BACKEND_URL = "https://d7a2282a-3b49-4022-b654-3a52c3eae7ae-00-3u1h5ekdbuwyh.pike.replit.dev";
export const FRONTEND_URL = "https://d7a2282a-3b49-4022-b654-3a52c3eae7ae-00-3u1h5ekdbuwyh.pike.replit.dev";
export const OG_IMAGE = FRONTEND_URL + "/og.svg";
