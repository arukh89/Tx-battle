import React, { useState, useEffect } from 'react';
import { farcasterService, FarcasterUser } from '../services/farcasterService';

const WalletButton: React.FC<{setStatus:(s:string)=>void}> = ({setStatus}) => {
  const [user, setUser] = useState<FarcasterUser | null>(null);
  const [walletConnected, setWalletConnected] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check if user is already available from Farcaster context
    const checkCurrentUser = async () => {
      try {
        const currentUser = await farcasterService.getCurrentUser();
        if (currentUser?.fid) {
          const userData = await farcasterService.getUserByFid(currentUser.fid);
          setUser(userData);
          setStatus(`Logged in as @${userData.username} ✅`);
        }
      } catch (error) {
        console.log('No current user context available');
      }
    };

    checkCurrentUser();
  }, [setStatus]);

  const connectWallet = async () => {
    setLoading(true);
    try {
      // Try to connect wallet through SDK
      const walletResult = await farcasterService.connectWallet();
      
      if (walletResult?.address) {
        setWalletConnected(true);
        setStatus(`Wallet connected: ${walletResult.address.slice(0,6)}...${walletResult.address.slice(-4)} ✅`);
        
        // Try to get user data from connected wallet address
        try {
          const users = await farcasterService.getUsersByAddresses([walletResult.address]);
          if (users.length > 0) {
            setUser(users[0]);
            setStatus(`Connected as @${users[0].username} ✅`);
          }
        } catch (error) {
          console.log('Could not fetch user data from wallet address');
        }
      } else if (farcasterService.isFarcasterEnvironment()) {
        setStatus('Wallet connection not available in this environment');
      } else {
        setStatus('Running in development mode - Farcaster features limited');
      }
    } catch (error) {
      console.error('Wallet connection error:', error);
      setStatus('Wallet connection failed ❌');
    } finally {
      setLoading(false);
    }
  };

  const disconnect = () => {
    setUser(null);
    setWalletConnected(false);
    setStatus('Disconnected');
  };

  return (
    <section className="wallet-section card">
      {user ? (
        <div className="user-info">
          <div className="user-profile">
            <img 
              src={user.pfpUrl || '/icons/icon-192.svg'} 
              alt={user.displayName}
              className="user-avatar"
              style={{ width: '32px', height: '32px', borderRadius: '16px' }}
            />
            <div>
              <div className="user-name">{user.displayName}</div>
              <div className="user-handle">@{user.username}</div>
            </div>
          </div>
          <button className="wallet-btn disconnect" onClick={disconnect}>
            Disconnect
          </button>
        </div>
      ) : (
        <button 
          id="connectWalletBtn" 
          className="wallet-btn" 
          onClick={connectWallet}
          disabled={loading}
        >
          {loading ? 'Connecting...' : 'Connect Farcaster'}
        </button>
      )}
    </section>
  );
};

export default WalletButton;
